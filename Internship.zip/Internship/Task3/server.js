
const express = require("express");

const app = express();
const PORT = 3000;

// Read JSON data from requests
app.use(express.json());

// In-memory storage
let notes = [
    { id: 1, title: "First Note", content: "Welcome to my Notes API" },
    { id: 2, title: "Second Note", content: "Learning Node.js and Express" }
];

let nextId = 3;

// 1. GET - View all notes
app.get("/notes", (req, res) => {
    res.json(notes);
});

// 2. GET - View one note by ID
app.get("/notes/:id", (req, res) => {
    const id = Number(req.params.id);
    const note = notes.find(note => note.id === id);

    if (!note) {
        return res.status(404).json({ message: "Note not found" });
    }

    res.json(note);
});

// 3. POST - Add a new note
app.post("/notes", (req, res) => {
    const { title, content } = req.body;

    if (
        typeof title !== "string" || !title.trim() ||
        typeof content !== "string" || !content.trim()
    ) {
        return res.status(400).json({
            message: "Please provide a title and content"
        });
    }

    const newNote = {
        id: nextId++,
        title: title.trim(),
        content: content.trim()
    };

    notes.push(newNote);

    res.status(201).json({
        message: "Note added successfully",
        note: newNote
    });
});

// 4. PUT - Update an existing note
app.put("/notes/:id", (req, res) => {
    const id = Number(req.params.id);
    const note = notes.find(note => note.id === id);

    if (!note) {
        return res.status(404).json({ message: "Note not found" });
    }

    const { title, content } = req.body;

    if (
        typeof title !== "string" || !title.trim() ||
        typeof content !== "string" || !content.trim()
    ) {
        return res.status(400).json({
            message: "Please provide a title and content"
        });
    }

    note.title = title.trim();
    note.content = content.trim();

    res.json({
        message: "Note updated successfully",
        note: note
    });
});

// 5. DELETE - Delete a note
app.delete("/notes/:id", (req, res) => {
    const id = Number(req.params.id);
    const index = notes.findIndex(note => note.id === id);

    if (index === -1) {
        return res.status(404).json({ message: "Note not found" });
    }

    const deletedNote = notes.splice(index, 1)[0];

    res.json({
        message: "Note deleted successfully",
        note: deletedNote
    });
});

// Handle unknown routes
app.use((req, res) => {
    res.status(404).json({ message: "Route not found" });
});

// Start the server
app.listen(5500, () => {
    console.log(`Server running at http://localhost:5500`);
});
